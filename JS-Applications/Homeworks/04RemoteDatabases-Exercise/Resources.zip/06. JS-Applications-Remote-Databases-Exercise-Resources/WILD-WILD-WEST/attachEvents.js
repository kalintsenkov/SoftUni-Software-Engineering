function attachEvents() {
    console.log("TODO...");
}
function solve() {
    // TODO ...
}


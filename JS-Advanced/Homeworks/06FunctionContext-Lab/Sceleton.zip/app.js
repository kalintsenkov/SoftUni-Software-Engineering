function solve() {
    // ToDo
}
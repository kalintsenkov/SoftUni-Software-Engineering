function solve() {
  // TODO:
}

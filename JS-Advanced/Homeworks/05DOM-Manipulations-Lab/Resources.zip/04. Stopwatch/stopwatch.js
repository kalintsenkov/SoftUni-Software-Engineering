function stopwatch() {
    console.log('TODO:...');
}
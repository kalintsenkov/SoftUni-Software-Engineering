function solve() {
   //TODO...
}


